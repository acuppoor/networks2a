package thread;

import byte_array_size.ByteArraySize;

import java.io.*;
import java.net.Socket;
import java.net.UnknownServiceException;

/**
 * Created by Arjun on 4/5/2017.
 */
public class MessageSenderToServerForClient extends Thread {
    private PrintWriter p;
    private BufferedReader bufferedReader;
    private Socket socket;
    private volatile boolean interrupted = false;

    public MessageSenderToServerForClient(Socket socket){ // Reads message from client and sends it to server
        this.socket = socket;
        this.bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    }

    public void run(){
        while(!interrupted && !socket.isClosed()) {
            try {
                String message = bufferedReader.readLine(); // standard input
                if(message.trim().equalsIgnoreCase("@exit")){ // Exiting the chat
                    this.interrupt();

                } else if (message.toLowerCase().contains("@sendfile:")){ // Sending file to server

                    // Extracting the path of the file
                    String path;
                    File file;
                    try {
                        path = message.substring(message.indexOf(':')+1, message.length()).trim();
                        if(path.trim().equals("")){
                            throw new UnknownServiceException();
                        }
                        file = new File(path);
                        System.out.println("(Path of file being sent: " + path + ")");
                    } catch (Exception e){
                        path = System.getProperty("user.dir") + "/src/files/dog.png";
                        System.out.println("(Path Extraction Error, Assumed path: " + path + ")");
                        file = new File(path);
                    }

                    OutputStream out = socket.getOutputStream();

                    p = new PrintWriter(out); // get the output stream to the server
                    p.println("@ReceiveFileRequest: File Received from port " + socket.getPort()); // sends the message to the server
                    p.flush(); // so that the bytes get to the server
                    System.out.println("(Server has been requested to receive the file)");


                    FileInputStream fileInputStream = new FileInputStream(file);
                    //BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);

                    byte[] bytes = new byte[ByteArraySize.ByteArraySize];
                    System.out.println("(Sending File...)");

                    int count;
                    while ((count = fileInputStream.read(bytes))> 0) {
                        out.write(bytes, 0, count);
                    }

                    System.out.println("(File Sent)");

                    p = new PrintWriter(out);
                    p.println("@FileReceived: File Received from port " +  socket.getPort());
                    p.flush();

                    System.out.println("(Server has been notified of file received)");

                } else {
                    p = new PrintWriter(socket.getOutputStream());
                    p.println(message);
                    p.flush();
                    System.out.println("(Message Sent)");
                }
            } catch (java.net.SocketException e1){
                this.interrupt();
            }catch (Exception e2) {
            }
        }
        //System.exit(0);
    }

    public void interrupt(){
        this.interrupted = true;
        try{
            if(bufferedReader != null) {
                bufferedReader.close();
            }

            if(p!= null){
                p.close();
            }

            socket.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}