package byte_array_size;

/**
 * Created by Arjun on 4/5/2017.
 */
public class ByteArraySize {
    public static int ByteArraySize = 16*1024;

    private ByteArraySize(){}
}
